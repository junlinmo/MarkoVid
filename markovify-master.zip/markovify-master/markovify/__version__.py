VERSION_TUPLE = (0, 7, 1)
__version__ = ".".join(map(str, VERSION_TUPLE))
